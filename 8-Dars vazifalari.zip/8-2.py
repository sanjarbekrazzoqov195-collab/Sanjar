import os
os.system("cls")
from datetime import date
def hisobla_kun(yil, oy, kun):
    tugilgan_sana = date(yil, oy, kun)
    bugun = date.today()
    
    farq = bugun - tugilgan_sana
    return farq.days
yil = int(input("Yil: "))
oy = int(input("Oy: "))
kun = int(input("Kun: "))
natija = hisobla_kun(yil, oy, kun)
print("Tug'ilganingizdan beri o'tgan kunlar soni:", natija)