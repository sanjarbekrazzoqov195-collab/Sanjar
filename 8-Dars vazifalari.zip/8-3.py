import os
os.system("cls")
from datetime import datetime
def mustaqillik_kunigacha():
    bugun = datetime.now()
    yil = bugun.year
    bayram = datetime(yil, 9, 1)
    if bugun > bayram:
        bayram = datetime(yil + 1, 9, 1)

    farq = bayram - bugun
    print(f"Mustaqillik bayramigacha {farq.days} kun qoldi.")

mustaqillik_kunigacha()