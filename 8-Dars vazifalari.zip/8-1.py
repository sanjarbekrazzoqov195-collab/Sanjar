import os
os.system("cls")
from datetime import datetime

def hozirgi_sana():
    sana = datetime.now()
    print("Hozirgi sana:", sana.strftime("%d-%m-%Y"))

hozirgi_sana()