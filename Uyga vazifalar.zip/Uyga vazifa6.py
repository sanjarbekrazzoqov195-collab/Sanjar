import os
os.system("cls")

class Kurs:
    def __init__(self, nomi, davomiylik):
        self.nomi = nomi
        self.davomiylik = davomiylik
        self.talabalar = []

    def talaba_qoshish(self, ism):
        self.talabalar.append(ism)
        print(f"{ism} kursga qo'shildi.")

    def talabalar_soni(self):
        return len(self.talabalar)

kurs1 = Kurs("Python Dasturlash", "3 oy")
kurs1.talaba_qoshish("Ali")
kurs1.talaba_qoshish("Vali")
kurs1.talaba_qoshish("Hasan")
print("Talabalar soni:", kurs1.talabalar_soni())