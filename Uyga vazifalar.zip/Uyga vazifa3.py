import os
os.system("cls")

class Avtomobil:
    def __init__(self, model, yil, tezlik):
        self.model = model
        self.yil = yil
        self.tezlik = tezlik

    def tezlashtir(self):
        self.tezlik += 10

    def sekinlashtir(self):
        self.tezlik -= 10

    def info(self):
        print(f"Model: {self.model}")
        print(f"Yil: {self.yil}")
        print(f"Tezlik: {self.tezlik} km/soat")

avto1 = Avtomobil("Spark", 2013, 400000)

avto1.tezlashtir()
avto1.tezlashtir()
avto1.sekinlashtir()
avto1.info()