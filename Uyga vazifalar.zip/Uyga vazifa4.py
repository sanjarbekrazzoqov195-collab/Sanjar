import os
os.system("cls")
class BankHisob:
    def __init__(self, ism, balans=0):
        self.ism = ism
        self.balans = balans

    def deposit(self, summa):
        self.balans += summa
        print(f"{summa} so'm qo'shildi.")

    def yechib_ol(self, summa):
        if summa <= self.balans:
            self.balans -= summa
            print(f"{summa} so'm yechildi.")
        else:
            print("Balansda mablag' yetarli emas!")

    def hisob(self):
        return self.balans
hisob1 = BankHisob("Sanjarbek")
hisob1.deposit(1000)

hisob1.yechib_ol(400)
print("Hozirgi balans:", hisob1.hisob(), "so'm")