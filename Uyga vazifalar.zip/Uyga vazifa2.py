import os
os.system("cls")

class Kitob:
    def __init__(self, nomi, muallif, sahifa_soni):
        self.nomi = nomi
        self.muallif = muallif
        self.sahifa_soni = sahifa_soni

    def qisqacha(self):
        return f"Kitob: {self.nomi}, Muallif: {self.muallif}, Sahifalar soni: {self.sahifa_soni}"

    def katta_kitobmi(self):
        return self.sahifa_soni > 300
kitob1 = Kitob("O'tkan kunlar", "Abdulla Qodiriy", 350)
print(kitob1.qisqacha())
print(kitob1.katta_kitobmi())