import os
os.system("cls")

class Mahsulot:
    def __init__(self, nom, narx, miqdor):
        self.nom = nom
        self.narx = narx
        self.miqdor = miqdor

    def sotib_ol(self, miqdor):
        if miqdor <= self.miqdor:
            self.miqdor -= miqdor
            print(f"{miqdor} ta {self.nom} sotib olindi.")
        else:
            print("Yetarli mahsulot yo'q!")

    def qolgan_miqdor(self):
        return self.miqdor

mahsulot1 = Mahsulot("Olma", 5000, 20)
mahsulot1.sotib_ol(5)
mahsulot1.sotib_ol(3)
print("Qolgan mahsulot:", mahsulot1.qolgan_miqdor())