import os
os.system("cls")
def birlashtir(list1, list2):
    natija = []
    max_len = max(len(list1), len(list2))
    
    for i in range(max_len):
        if i < len(list1):
            natija.append(list1[i])
        if i < len(list2):
            natija.append(list2[i])
    
    return natija
list1=[1, 2, 3] 
list2=[11, 22, 33]

print(birlashtir(list1, list2))