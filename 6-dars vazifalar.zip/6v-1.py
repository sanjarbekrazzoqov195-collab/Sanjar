import os
os.system("cls")
def nolni_oxiriga_otkaz(lst):
    nol_emaslar = [son for son in lst if son != 0]
    nollar = [0] * (len(lst) - len(nol_emaslar))
    return nol_emaslar + nollar

lst = [3,4,0,0,0,6,2,0,6,7,6,0,0,0,9,10,7,4,4,5,3,0,0,2,9,7,1]
natija = nolni_oxiriga_otkaz(lst)
print(natija)