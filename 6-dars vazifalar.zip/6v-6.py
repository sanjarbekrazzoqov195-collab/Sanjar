import os
os.system("cls")
kvadrat = lambda lst: list(map(lambda son: son**2, lst))
sonlar = [1,2,3,4,5,6,7,8,9,10]
print(kvadrat(sonlar))