import os
os.system("cls")
def dublikatni_olib_tashla(lst):
    natija = []
    for son in lst:
        if son not in natija:
            natija.append(son)
    return natija
lst =  [[10, 20], [40], [30, 56, 25], [10, 20], [33], [40]]
print(dublikatni_olib_tashla(lst))