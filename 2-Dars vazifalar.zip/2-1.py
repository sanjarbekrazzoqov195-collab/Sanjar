import os
os.system("cls")
n = int(input("n ni kiriting: "))
yigindi = 0

for i in range(1, n + 1):
    print(i, end=" ")
    yigindi += i

print("\nYig'indi:", yigindi)