import os
os.system("cls")
for son in range(10, 100):
    tub = True
    if son < 2:
        tub = False
    else:
        for i in range(2, int(son ** 0.5) + 1):
            if son % i == 0:
                tub = False
                break
    
    if tub:
        print(son, end=" ")