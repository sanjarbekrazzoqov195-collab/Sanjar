import os
os.system("cls")
son = input("Son kiriting: ")

for raqam in son[::-1]:
    print(raqam, end=" ")