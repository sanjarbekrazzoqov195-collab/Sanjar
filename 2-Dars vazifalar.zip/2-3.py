import os
os.system("cls")
son = input("Son kiriting: ")

for raqam in son:
    print(raqam, end=" ")