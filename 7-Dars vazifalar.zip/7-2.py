import os
os.system("cls")
def ortacha_ball(students):
    natijalar = []
    for ism, fanlar in students.items():
        ortacha = sum(fanlar.values()) / len(fanlar)
        natijalar.append(f"{ism}: {ortacha}")
    return ", ".join(natijalar)

students = {
    "Ali": {"math": 90, "en": 80},
    "Vali": {"math": 70, "en": 85}
}

print(f"Natija: {ortacha_ball(students)}")