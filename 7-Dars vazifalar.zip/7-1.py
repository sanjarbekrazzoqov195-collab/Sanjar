import os
os.system("cls")
def eng_kop_uchraydigan(matn, k=3):
    sozlar = matn.split()
    hisob = {}
    for soz in sozlar:
        hisob[soz] = hisob.get(soz, 0) + 1
    
    saralangan = sorted(hisob.items(), key=lambda x: x[1], reverse=True)
    return [item[0] for item in saralangan[:k]]

input_matn = "olma nok olma gilos olma nok shaftoli"
print(*(eng_kop_uchraydigan(input_matn)))