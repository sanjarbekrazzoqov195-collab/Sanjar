import os
os.system("cls")
def ombor_tahlil(ombor):
    jami = sum(item["miqdor"] for item in ombor)
    saralangan = sorted(ombor, key=lambda x: x["miqdor"])
    eng_kam_3 = saralangan[:3]
    
    return jami, eng_kam_3

ombor = [
    {"mahsulot": "olma", "miqdor": 5},
    {"mahsulot": "nok", "miqdor": 9},
    {"mahsulot": "shaftoli", "miqdor": 7},
    {"mahsulot": "anor", "miqdor": 4},
    {"mahsulot": "banan", "miqdor": 6},
    {"mahsulot": "uzum", "miqdor": 8},
    {"mahsulot": "gilos", "miqdor": 2},
    {"mahsulot": "tarvuz", "miqdor": 1},
    {"mahsulot": "qovun", "miqdor": 3},
    {"mahsulot": "limon", "miqdor": 5}
]
jami, eng_kam_3 = ombor_tahlil(ombor)

print("Jami miqdor:", jami)
print("Eng kam qolgan 3 ta mahsulot:", eng_kam_3)