import os
os.system("cls")
lst = [(10, 20, 40), (40, 50, 60), (70, 80, 90)]

yangi = []

for t in lst:
    yangi_tuple = t[:-1] + (100,) 
    yangi.append(yangi_tuple)

print(yangi)