import os
os.system("cls")
t = (1,2,3,4,5,6,7,8,9,10)

print(t[3], t[-4])