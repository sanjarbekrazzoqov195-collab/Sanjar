import os
os.syst em("cls")


lst = [[1,2,3], [4,5,6], [10,11,12], [7,8,9]]

max_list = lst[0]
max_sum = sum(lst[0])

for inner in lst:
    if sum(inner) > max_sum:
        max_sum = sum(inner)
        max_list = inner

print(max_list)