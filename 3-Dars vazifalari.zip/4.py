import os
os.system("cls")
class Taqvim:

    def hijriyga(self, yil):
        hijriy_yil = int((yil - 622) * 33 / 32)
        return hijriy_yil

    def grigoriyanga(self, yil):
        grigoriy_yil = int((yil * 32 / 33) + 622)
        return grigoriy_yil

    def kabisami(self, yil):

        if (yil % 4 == 0 and yil % 100 != 0) or (yil % 400 == 0):
            return True
        else:
            return False

obj = Taqvim()
print(obj.hijriyga(2026))
print(obj.grigoriyanga(1447))

print(obj.kabisami(2024))  
print(obj.kabisami(2025))  