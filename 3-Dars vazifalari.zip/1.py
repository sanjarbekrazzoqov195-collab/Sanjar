import os
os.system("cls")
class Talaba:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def __str__(self):
        return f"{self.name} ({self.age} yosh)"
class Kurs:
    def __init__(self, kurs_name, kurs_teacher):
        self.kurs_name = kurs_name
        self.kurs_teacher = kurs_teacher
        self.talabalar_soni = 0
        self.talabalar = []

    def add(self, new_student):
        self.talabalar.append(new_student)
        self.talabalar_soni += 1
        print(f"{new_student.name} kursga qo'shildi.")

    def delete(self, new_student):
        if new_student in self.talabalar:
            self.talabalar.remove(new_student)
            self.talabalar_soni -= 1
            print(f"{new_student.name} kursdan chiqarildi.")
        else:
            print("Talaba topilmadi")

    def info_kurs(self):
        print(f"\nKurs nomi: {self.kurs_name}")
        print(f"O'qituvchi: {self.kurs_teacher}")
        print(f"Talabalar soni: {self.talabalar_soni}")
        print("Talabalar ro'yxati:")

        for talaba in self.talabalar:
            print("-", talaba)

kurs1 = Kurs("Bootcamp foundation", "Mirjamol")
kurs2 = Kurs("Bootcamp foundation2", "Ozodbek")

for i in range(1, 11):
    talaba = Talaba(f"Talaba_{i}", 18 + i)
    kurs1.add(talaba)

for i in range(11, 21):
    talaba = Talaba(f"Talaba_{i}", 18 + i)
    kurs2.add(talaba)

kurs1.delete(kurs1.talabalar[0])
kurs2.delete(kurs2.talabalar[1])

kurs1.info_kurs()
kurs2.info_kurs()