import os
os.system("cls")

class Convertor:

    def rus_to_eng(self, text):
        rus = {
            'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g',
            'д': 'd', 'е': 'e', 'ё': 'yo', 'ж': 'j',
            'з': 'z', 'и': 'i', 'й': 'y', 'к': 'k',
            'л': 'l', 'м': 'm', 'н': 'n', 'о': 'o',
            'п': 'p', 'р': 'r', 'с': 's', 'т': 't',
            'у': 'u', 'ф': 'f', 'х': 'x', 'ц': 'ts',
            'ч': 'ch', 'ш': 'sh', 'щ': 'sch', 'ъ': '',
            'ы': 'i', 'ь': '', 'э': 'e', 'ю': 'yu',
            'я': 'ya'
        }

        result = ""

        for harf in text.lower():
            result += rus.get(harf, harf)

        return result

    def eng_to_rus(self, text):
        eng = {
            'a': 'а', 'b': 'б', 'v': 'в', 'g': 'г',
            'd': 'д', 'e': 'е', 'z': 'з', 'i': 'и',
            'y': 'й', 'k': 'к', 'l': 'л', 'm': 'м',
            'n': 'н', 'o': 'о', 'p': 'п', 'r': 'р',
            's': 'с', 't': 'т', 'u': 'у', 'f': 'ф',
            'x': 'х'
        }

        result = ""

        for harf in text.lower():
            result += eng.get(harf, harf)

        return result


obj = Convertor()

print(obj.rus_to_eng("Привет"))
print(obj.eng_to_rus("salom"))