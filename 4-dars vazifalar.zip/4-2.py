import os
os.system("cls")

set1 = {"olma", "anor", "youtube", "instagram", "tesla", "nissan"}
set2 = {"apple", "elon mask", "apple", "vaz", "bmw", "tesla", "nissan"}
set3 = {"youtube", "olma", "instagram", "tesla", "nissan"}
kesishma = set1 & set2
natija = kesishma - set3
print(f"Natija: {natija}")