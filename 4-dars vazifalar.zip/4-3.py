import os
os.system("cls")
set1 = {1, 2, 3, 4, 5, 6}
set2 = {4, 5, 6, 7, 8, 9}

umumiy_bolmaganlar = set1 ^ set2
natija = sorted(umumiy_bolmaganlar, reverse=True)
print( *natija)