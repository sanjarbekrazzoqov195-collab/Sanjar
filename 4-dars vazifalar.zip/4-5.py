import os
os.system("cls")
soz1 = input("1-so'zni kiriting: ")
soz2 = input("2-so'zni kiriting: ")
if sorted(soz1) == sorted(soz2):
    print(True)
else:
    print(False)