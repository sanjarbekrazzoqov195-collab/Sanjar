import os
os.system("cls")
ali = {"Toshkent", "Samarqand", "Buxoro", "Andijon"}
vali = {"Toshkent", "Farg'ona", "Buxoro", "Xiva"}
ikkala_dost = ali.intersection(vali)
ali = ali.difference(vali)
print("Ikkala do'st ham borgan shaharlar:", ikkala_dost)
print("Faqat Ali borgan shaharlar:", ali)