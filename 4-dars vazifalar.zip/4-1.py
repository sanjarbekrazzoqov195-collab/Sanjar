import os
os.system("cls")
set1 = {1, 2, 3, 4, 5, 6}
set2 = {4, 5, 6, 7, 8, 9}

umumiy = set1.intersection(set2)
umumiy_sum = sum(umumiy)
birinchi = set1.difference(set2)
birinchi_sum = sum(birinchi)
natija = umumiy_sum - birinchi_sum
print(f"Natija: {natija}")