import os
os.system("cls")
# input fayldan o'qish
with open("input.txt", "r") as fayl:
    data = fayl.read()

# ASCII kodlarni listga ajratish
ascii_raqamlar = data.split()

# har bir kodni belgiga aylantirish
matn = ""
for kod in ascii_raqamlar:
    matn += chr(int(kod))

# natijani yangi faylga yozish
with open("output.txt", "w") as fayl:
    fayl.write(matn)

print("Matn muvaffaqiyatli yozildi!")