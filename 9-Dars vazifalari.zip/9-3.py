import os
os.system("cls")
with open('matn.txt', 'r', encoding='utf-8') as file:
    content = file.read()
updated_content = content.title()

with open('output3.txt', 'w', encoding='utf-8') as out_file:
    out_file.write(updated_content)

print(" Hammaa so'zlar bosh harf bilan yozildi.")