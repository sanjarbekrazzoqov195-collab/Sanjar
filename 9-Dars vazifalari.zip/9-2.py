import os
os.system("cls")
word_to_find = input("Qidirilayotgan so'zni kiriting: ")

with open('python_matn.txt', 'r', encoding='utf-8') as file:
    content = file.read()
    if word_to_find in content:
        print(f"Siz kiritgan '{word_to_find}' so'zi faylda bor.")
    else:
        print(f"Siz kiritgan '{word_to_find}' so'zi faylda yo'q.")