import os
os.system("cls")
professions = {
    "Bill Gates": "Dasturchi",
    "Cristiano Ronaldo": "Futbolchi",
    "Elon Musk": "Tadbirkor",
    "Messi": "Futbolchi"
}
ism = input("Ism kiriting: ")
if ism in professions:
    print(f"{ism}ning kasbi: {professions[ism]}")
else:
    print("Kechirasiz, bu ism haqida ma'lumot topilmadi.")
    