import os
os.system("cls")
car_count = {
    "Chevrolet": 120,
    "Toyota": 95,
    "BMW": 60,
    "Kia": 75
}
max_sotilgan = max(car_count.values())
min_sotilgan = min(car_count.values())
most_sotilgan_cars = [car for car, count in car_count.items() if count == max_sotilgan]
least_sotilgan_cars = [car for car, count in car_count.items() if count == min_sotilgan]
print(f"Eng ko'p sotilgan mashina: {', '.join(most_sotilgan_cars)} ({max_sotilgan} ta)")
print(f"Eng kam sotilgan mashina: {', '.join(least_sotilgan_cars)} ({min_sotilgan} ta)")