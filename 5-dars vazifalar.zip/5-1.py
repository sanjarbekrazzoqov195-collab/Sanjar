import os
os.system("cls")
cars = {
    "Malibu": 35000,
    "Gentra": 15000,
    "Spark": 12000,
    "Cobalt": 13000,
    "Tracker": 24000
}
narxlar = list(cars.values())
eng_qimmat = max(narxlar)
eng_arzon = min(narxlar)
ortacha_narx = sum(narxlar) / len(narxlar)
print(f"Eng qimmat avtomobil: {eng_qimmat}")
print(f"Eng arzon avtomobil: {eng_arzon}")
print(f"Avtomobillarning o'rtacha: {ortacha_narx}")