import json
import os
os.system("cls")
with open("users.json", "r", encoding="utf-8") as fayl:
    users = json.load(fayl)

print("Foydalanuvchilar soni:", len(users))