import json
import os
os.system("cls")
with open("users.json", "r", encoding="utf-8") as fayl:
    users = json.load(fayl)

print("Yoshi 18 dan katta foydalanuvchilar:")

for user in users:
    if user["age"] > 18:
        print(user)