import os
os.system("cls")
try:
    with open('data.txt', 'r') as file:
        mevalar = [line.strip() for line in file.readlines() if line.strip()]
        
    if not mevalar:
        print("Fayl bo'sh")
    else:
        print(mevalar)

except FileNotFoundError:
    print("Fayl topilmadi")
except Exception as e:
    print(f"Xatolik yuz berdi: {e}")