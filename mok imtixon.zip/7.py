import os
os.system("cls")
try:
    son1 = float(input("1-sonni kiriting: "))
    son2 = float(input("2-sonni kiriting: "))

    natija = son1 / son2
    print("Bo‘linma:", natija)

except ZeroDivisionError:
    print("Nolga bo‘lish mumkin emas")

except ValueError:
    print("Faqat son kiriting")