matn = "salom dunyo salom python dunyo salom"

sozlar = matn.split()
natija = {}

for soz in sozlar:
    natija[soz] = sozlar.count(soz)

print(natija)