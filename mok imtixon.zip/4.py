import json
import os
os.system("cls")
data = [{"name": "Ali"}, {"name": "Vali"}]

with open("data.json", "w") as file:
    json.dump(data, file, indent=4)