import os
os.system("cls")
def lugat_birlashtir(d1, d2):
    natija = d1.copy()

    for kalit, qiymat in d2.items():
        if kalit in natija:
            natija[kalit] += qiymat
        else:
            natija[kalit] = qiymat

    return natija


d1 = {"a": 1, "b": 2, "c": 3}
d2 = {"b": 4, "d": 5}

print(lugat_birlashtir(d1, d2))