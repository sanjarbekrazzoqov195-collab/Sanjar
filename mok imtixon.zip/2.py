import os
os.system("cls")
data = [("Ali", 85), ("Vali", 92), ("Sami", 77)]

natija = dict(data)

print(natija)