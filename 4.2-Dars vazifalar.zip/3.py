import os
os.system("cls")
class User:
    def __init__(self, name, username):
        self.name = name
        self.username = username
        self.followers = []
        self.following = []

    def follow(self, user):
        if user not in self.following:
            self.following.append(user)

    def unfollow(self, user):
        if user in self.following:
            self.following.remove(user)

    def remove_follower(self, user):
        if user in self.followers:
            self.followers.remove(user)

    def info(self):
        print(f"Name: {self.name}")
        print(f"Username: @{self.username}")
        print("Followers:", self.followers)
        print("Following:", self.following)


user1 = User("Suhrob", "suhrob_07")
user2 = User("Ayub", "ayub_09")
user3 = User("Joxon", "joxon_03")

user1.follow(user2.username)
user1.follow(user3.username)

user1.followers.append(user2.username)
user1.followers.append(user3.username)

print("Dastlabki holat:")
user1.info()
user1.unfollow(user3.username)
user1.remove_follower(user2.username)

print("\nYangilangan holat:")
user1.info()