import os
os.system("cls")
class Avto:
    def __init__(self, nomi, rangi, narxi, probegi, tezligi):
        self.nomi = nomi
        self.rangi = rangi
        self.narxi = narxi
        self.probegi = probegi
        self.tezligi = tezligi

    def update_probeg(self, yangi_probeg):
        self.probegi = yangi_probeg

    def update_narx(self, yangi_narx):
        self.narxi = yangi_narx

    def info(self):
        print(f"Avto nomi: {self.nomi}")
        print(f"Rangi: {self.rangi}")
        print(f"Narxi: {self.narxi}$")
        print(f"Probegi: {self.probegi} km")
        print(f"Tezligi: {self.tezligi} km/soat")


avto1 = Avto("Malibu", "Qora", 30000, 50000, 220)

print("Eski ma'lumotlar:")
avto1.info()

avto1.update_probeg(55000)
avto1.update_narx(28000)

print("\nYangilangan ma'lumotlar:")
avto1.info()