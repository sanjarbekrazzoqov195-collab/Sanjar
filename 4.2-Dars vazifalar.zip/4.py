import os
os.system("cls")
class Phone:
    def __init__(self, brand, model, narx, yili):
        self.brand = brand
        self.model = model
        self.narx = narx
        self.yili = yili

    def update_price(self, yangi_narx):
        self.narx = yangi_narx

    def info(self):
        print(f"Brand: {self.brand}")
        print(f"Model: {self.model}")
        print(f"Narx: {self.narx}$")
        print(f"Yili: {self.yili}")


phone1 = Phone("Apple", "iPhone 17", 1500, 2025)

print("Eski narx:")
phone1.info()

phone1.update_price(1300)

print("\nYangi narx:")
phone1.info()