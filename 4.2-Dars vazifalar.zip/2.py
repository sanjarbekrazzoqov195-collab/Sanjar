import os
os.system("cls")

class Restoran:
    def __init__(self, ish_vaqti, menyu):
        self.ish_vaqti = ish_vaqti
        self.menyu = menyu

    def taom_qoshish(self, ovqat):
        self.menyu.append(ovqat)

    def get_ish_vaqti(self):
        return self.ish_vaqti

    def show_menyu(self):
        print("Menyu:")
        for food in self.menyu:
            print(food)


restoran1 = Restoran("09:00 - 23:00", ["Osh", "Shashlik", "Lag'mon"])

restoran1.show_menyu()

restoran1.taom_qoshish("Somsa")

print("\nYangilangan menyu:")
restoran1.show_menyu()

print("\nIsh vaqti:", restoran1.get_ish_vaqti())