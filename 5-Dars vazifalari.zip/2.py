import sys
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QPushButton

app = QApplication(sys.argv)

window = QWidget()
window.setWindowTitle("Ma'lumotlar")
window.setGeometry(300, 300, 350, 200)

label = QLabel("Ma'lumot", window)
label.move(130, 40)

btn1 = QPushButton("Ism", window)
btn1.move(20, 100)

btn2 = QPushButton("Familiya", window)
btn2.move(130, 100)

btn3 = QPushButton("Tug'ilgan sana", window)
btn3.move(230, 100)

def ism():
    label.setText("Sanjarbek")
    label.adjustSize()

def familiya():
    label.setText("Razzoqov")
    label.adjustSize()

def sana():
    label.setText("12.10.2003")
    label.adjustSize()

btn1.clicked.connect(ism)
btn2.clicked.connect(familiya)
btn3.clicked.connect(sana)

window.show()
sys.exit(app.exec_())