import sys
from PyQt5.QtWidgets import *

app = QApplication(sys.argv)

oyna = QWidget()
oyna.resize(300, 200)

txt1 = QLineEdit(oyna)
txt1.move(50, 20)

txt2 = QLineEdit(oyna)
txt2.move(50, 50)

natija = QLabel("Javob", oyna)
natija.move(50, 170)

def qosh():
    natija.setText(str(int(txt1.text()) + int(txt2.text())))

def ayir():
    natija.setText(str(int(txt1.text()) - int(txt2.text())))

def kop():
    natija.setText(str(int(txt1.text()) * int(txt2.text())))

def bol():
    natija.setText(str(int(txt1.text()) / int(txt2.text())))

b1 = QPushButton("+", oyna)
b1.move(20, 100)
b1.clicked.connect(qosh)

b2 = QPushButton("-", oyna)
b2.move(80, 100)
b2.clicked.connect(ayir)

b3 = QPushButton("*", oyna)
b3.move(140, 100)
b3.clicked.connect(kop)

b4 = QPushButton("/", oyna)
b4.move(200, 100)
b4.clicked.connect(bol)

oyna.show()
sys.exit(app.exec_())