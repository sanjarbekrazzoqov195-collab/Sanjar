import sys
from PyQt5.QtWidgets import *

app = QApplication(sys.argv)

oyna = QWidget()
oyna.resize(300, 200)

txt = QLineEdit(oyna)
txt.move(50, 30)
txt.setEchoMode(QLineEdit.Password)  # Parolni yashiradi

label = QLabel("", oyna)
label.move(50, 120)

btn = QPushButton("Tekshirish", oyna)
btn.move(50, 70)

def tekshir():
    if txt.text() == "12345":
        label.setText("Parol to'g'ri")
    else:
        label.setText("Noto'g'ri parol")

btn.clicked.connect(tekshir)

oyna.show()
sys.exit(app.exec_())