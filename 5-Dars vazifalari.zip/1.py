import sys
import random
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QPushButton

app = QApplication(sys.argv)

window = QWidget()
window.setWindowTitle("Random Son")
window.setGeometry(300, 300, 300, 200)

label = QLabel("Son chiqadi", window)
label.move(110, 50)

button = QPushButton("Random Son", window)
button.move(100, 100)

def chiqar():
    label.setText(str(random.randint(1, 100)))
    label.adjustSize()

button.clicked.connect(chiqar)

window.show()
sys.exit(app.exec_())